




// JavaScript to handle form submission and show alert
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting normally
    alert('Thank you for your message'); // Show the alert
    document.getElementById('contactForm').reset(); // Optional: Reset the form fields
});


